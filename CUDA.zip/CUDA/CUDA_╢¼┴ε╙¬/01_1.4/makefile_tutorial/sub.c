float subtraction(float a, float b)
{
    return (a-b);
}
