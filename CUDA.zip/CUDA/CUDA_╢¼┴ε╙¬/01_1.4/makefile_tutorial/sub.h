#ifndef SUBTRACTION_H
#define SUBTRACTION_H

float subtraction(float a, float b);
#endif/*SUBTRACTION_H*/
